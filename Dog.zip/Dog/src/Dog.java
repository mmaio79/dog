import java.lang.String;

public class Dog {

    int ageDog;
    String nameDog;
    String[] toysDog = {"ball", "me", "stick"};
    private int playDog = 0;

    public Dog(String nameDog, int ageDog) {

        this.nameDog = nameDog;
        this.ageDog = ageDog;

    }

    public void bark() {
        System.out.println( "Bau bau!" );
    }

    public int getAgeDog() {
        return this.ageDog * 7;
    }

    public void playDogs (){
        this.playDog = (this.playDog + 1) % 3;
        String item = this.toysDog[this.playDog];
        System.out.println( nameDog + " play with " + item + "." );

    }


}

