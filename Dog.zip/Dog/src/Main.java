public class Main {

    public static void main(String[] args) {

        Dog d = new Dog( "Dot", 6 );

        d.bark();

        int dogYears = d.getAgeDog();
        System.out.println( dogYears + " dog years." );

        d.playDogs();
        d.playDogs();
        d.playDogs();
        d.playDogs();
    }
}
